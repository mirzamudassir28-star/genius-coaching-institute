
# GENIUS COACHING INSTITUTE – Review Booster

## Run Locally
npm install
npm run dev

## Build
npm run build

## Deploy on Vercel
- Import project into Vercel
- Framework preset: Vite
- Build command: npm run build
- Output directory: dist
