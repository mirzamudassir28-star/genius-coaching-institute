
import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { motion } from "framer-motion";
import { Search, Copy, Star, Sparkles } from "lucide-react";

const reviews = [
  {
    "id": 1,
    "name": "Imran Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 2,
    "name": "Neha Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 3,
    "name": "Neha Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 4,
    "name": "Rehan Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 5,
    "name": "Kabir Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 6,
    "name": "Rohan Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 7,
    "name": "Ritika Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 8,
    "name": "Ayaan Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 9,
    "name": "Rehan Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 10,
    "name": "Imran Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 11,
    "name": "Rohan Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 12,
    "name": "Imran Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 13,
    "name": "Kunal Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 14,
    "name": "Kabir Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 15,
    "name": "Faizan Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 16,
    "name": "Arjun Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 17,
    "name": "Sana Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 18,
    "name": "Arjun Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 19,
    "name": "Pooja Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 20,
    "name": "Sameer Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 21,
    "name": "Kabir Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 22,
    "name": "Anaya Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 23,
    "name": "Sana Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 24,
    "name": "Aditi Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 25,
    "name": "Sameer Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 26,
    "name": "Farhan Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 27,
    "name": "Rehan Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 28,
    "name": "Rehan Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 29,
    "name": "Ritika Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 30,
    "name": "Rehan Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 31,
    "name": "Faizan Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 32,
    "name": "Yash Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 33,
    "name": "Arjun Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 34,
    "name": "Rohan Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 35,
    "name": "Farhan Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 36,
    "name": "Zoya Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 37,
    "name": "Pooja Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 38,
    "name": "Rohan Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 39,
    "name": "Yash Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 40,
    "name": "Rehan Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 41,
    "name": "Kabir Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 42,
    "name": "Ritika Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 43,
    "name": "Rehan Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 44,
    "name": "Ritika Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 45,
    "name": "Ayaan Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 46,
    "name": "Ritika Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 47,
    "name": "Arjun Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 48,
    "name": "Pooja Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 49,
    "name": "Zoya Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 50,
    "name": "Faizan Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 51,
    "name": "Pooja Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 52,
    "name": "Sameer Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 53,
    "name": "Ayaan Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 54,
    "name": "Faizan Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 55,
    "name": "Farhan Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 56,
    "name": "Sana Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 57,
    "name": "Farhan Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 58,
    "name": "Kunal Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 59,
    "name": "Neha Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 60,
    "name": "Ayaan Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 61,
    "name": "Imran Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 62,
    "name": "Zoya Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 63,
    "name": "Neha Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 64,
    "name": "Zoya Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 65,
    "name": "Neha Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 66,
    "name": "Priya Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 67,
    "name": "Rohan Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 68,
    "name": "Ritika Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 69,
    "name": "Ritika Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 70,
    "name": "Kunal Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 71,
    "name": "Rehan Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 72,
    "name": "Arjun Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 73,
    "name": "Rehan Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 74,
    "name": "Yash Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 75,
    "name": "Rohan Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 76,
    "name": "Kabir Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 77,
    "name": "Arjun Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 78,
    "name": "Aditi Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 79,
    "name": "Anaya Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 80,
    "name": "Ayaan Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 81,
    "name": "Anaya Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 82,
    "name": "Kabir Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 83,
    "name": "Ritika Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the best classes in Malad West. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 84,
    "name": "Pooja Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 85,
    "name": "Imran Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 86,
    "name": "Yash Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 87,
    "name": "Rehan Verma",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 88,
    "name": "Ritika Sharma",
    "text": "GENIUS COACHING INSTITUTE is one of the trusted coaching center. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 89,
    "name": "Sameer Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 90,
    "name": "Pooja Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 91,
    "name": "Aditi Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 92,
    "name": "Sameer Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 93,
    "name": "Yash Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the experienced teachers. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 94,
    "name": "Kunal Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 95,
    "name": "Aditi Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the best coaching classes in Malwani. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 96,
    "name": "Pooja Mehta",
    "text": "GENIUS COACHING INSTITUTE is one of the competitive exam coaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 97,
    "name": "Kunal Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the student success. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 98,
    "name": "Kunal Shaikh",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 99,
    "name": "Priya Patel",
    "text": "GENIUS COACHING INSTITUTE is one of the quality teaching. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  },
  {
    "id": 100,
    "name": "Ritika Khan",
    "text": "GENIUS COACHING INSTITUTE is one of the affordable coaching classes. Teachers are supportive, concepts are explained clearly, and the study environment helps students improve confidence and academic performance."
  }
];

function App() {
  const [search, setSearch] = useState("");
  const [copied, setCopied] = useState(null);
  const [generated, setGenerated] = useState("");
  const [keyword, setKeyword] = useState("");

  const filtered = useMemo(() => reviews.filter(r =>
    r.text.toLowerCase().includes(search.toLowerCase()) ||
    r.name.toLowerCase().includes(search.toLowerCase())
  ), [search]);

  const copyReview = async(text,id) => {
    await navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(()=>setCopied(null),2000);
  }

  const generateReview = () => {
    setGenerated(`GENIUS COACHING INSTITUTE provides amazing ${keyword} support with experienced teachers, personalized attention, and excellent results for students in Malwani and Malad West.`);
  }

  return (
    <div className="min-h-screen bg-black text-white font-[Inter] overflow-hidden">
      <div className="fixed inset-0 bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-transparent blur-3xl"></div>

      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-white/5 border-b border-white/10 p-4">
        <div className="max-w-7xl mx-auto flex flex-wrap gap-4 justify-between items-center">
          <h1 className="text-2xl font-black bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
            GENIUS COACHING INSTITUTE
          </h1>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2">
              <Search size={18} />
              <input
                placeholder="Search reviews..."
                className="bg-transparent outline-none"
                value={search}
                onChange={e=>setSearch(e.target.value)}
              />
            </div>

            <div className="bg-white/10 px-4 py-2 rounded-xl">
              {filtered.length} Reviews
            </div>

            <a href="https://g.page/r/CSw1EGSLWyD9EBM/review" target="_blank"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 hover:scale-105 transition">
              Review Now
            </a>
          </div>
        </div>
      </nav>

      <section className="max-w-7xl mx-auto px-6 py-20">
        <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}}>
          <h2 className="text-6xl font-black leading-tight bg-gradient-to-r from-white via-blue-300 to-purple-500 text-transparent bg-clip-text">
            Boost Your Google Presence
          </h2>
          <p className="text-gray-400 mt-5 text-lg">
            SEO optimized reviews crafted for maximum local ranking impact.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-4 gap-4 mt-10">
          {["100+ Ready Reviews","SEO Optimized","1-Click Copy","Instant Review Access"].map((s,i)=>(
            <div key={i} className="bg-white/5 border border-white/10 rounded-3xl p-6 backdrop-blur-xl">
              <Sparkles className="text-blue-400 mb-3"/>
              <h3 className="font-bold text-xl">{s}</h3>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white/5 rounded-3xl p-8 border border-white/10">
          <h3 className="text-3xl font-bold mb-6">AI Review Generator</h3>
          <div className="flex gap-4 flex-wrap">
            <input
              placeholder="Enter keyword..."
              value={keyword}
              onChange={e=>setKeyword(e.target.value)}
              className="bg-black/40 border border-white/10 rounded-xl px-4 py-3 flex-1"
            />
            <button onClick={generateReview}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600">
              Generate
            </button>
          </div>
          {generated && (
            <div className="mt-6 bg-black/40 rounded-2xl p-5 border border-blue-500/30">
              {generated}
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-16">
          {filtered.map(review => (
            <motion.div
              whileHover={{ y:-8 }}
              key={review.id}
              className="bg-white/5 border border-white/10 rounded-3xl p-6 backdrop-blur-xl shadow-2xl shadow-blue-500/10"
            >
              <p className="text-xs tracking-[4px] text-blue-400 mb-3 font-semibold">
                GENIUS COACHING INSTITUTE
              </p>

              <div className="flex justify-between items-center">
                <h3 className="text-xl font-bold">{review.name}</h3>
                <div className="flex text-yellow-400">
                  {[1,2,3,4,5].map(s => <Star key={s} size={16} fill="currentColor" />)}
                </div>
              </div>

              <p className="text-gray-300 mt-4 leading-relaxed">
                {review.text}
              </p>

              <div className="flex justify-between items-center mt-5">
                <span className="text-sm text-gray-500">
                  {review.text.length} chars
                </span>

                <div className="flex gap-3">
                  <button
                    onClick={()=>copyReview(review.text, review.id)}
                    className="px-4 py-2 rounded-xl bg-white/10 hover:bg-blue-500 transition flex items-center gap-2"
                  >
                    <Copy size={16} />
                    {copied === review.id ? "Copied!" : "Copy"}
                  </button>

                  <a href="https://g.page/r/CSw1EGSLWyD9EBM/review"
                    target="_blank"
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600">
                    Review Now
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="mt-20 text-center bg-white/5 border border-white/10 rounded-3xl p-16">
            <h3 className="text-3xl font-bold">No matching reviews found.</h3>
          </div>
        )}

        <footer className="mt-24 border-t border-white/10 py-10 text-center">
          <h3 className="text-2xl font-black bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
            GENIUS COACHING INSTITUTE
          </h3>
          <p className="text-gray-500 mt-3">
            SEO Optimized Reputation Management System
          </p>
        </footer>
      </section>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
